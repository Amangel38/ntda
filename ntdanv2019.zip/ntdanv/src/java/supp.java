/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author djo
 */
@WebServlet(urlPatterns = {"/supp"})
public class supp extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
    
        
        
                try {
            Class.forName("com.mysql.jdbc.Driver");
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(supp.class.getName()).log(Level.SEVERE, null, ex);
        }
           
      
Connection cn;
        try {
            cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ntda","root","");
      
        
        String email = request.getParameter("email");

String sql = "delete from email where id_email like  '"+email+"' ";

  
Statement stmp = cn.createStatement();
stmp.executeUpdate(sql);

      
response.sendRedirect("http://localhost:8080/ntdanv/index");



 ResultSet rs = null ;
           
                
           
      

//////afichage liste emails 

String liste_emails = " select * from `NTDA`.`email`  ";

Statement st = cn.createStatement();
 rs = st.executeQuery(liste_emails);  // execute men la base de donnéé


  
  
      out.println("<h1>recherche</h1>");



 out.println("expediteur      destinataire        objet         sujet   </br> ");
   
while (rs.next()){ 


        out.println(rs.getString("expediteur")+"   "+rs.getString("destinataire")+"   "+rs.getString("objet")+"  "+rs.getString("sujet")
                +"      <a href='http://localhost:8080/ntdanv/supp?email="+rs.getString("id_email")+"' >  Supprimer  </a>      </br> "); 
                            
   
     

  
   }

        
   } catch (SQLException ex) {
            Logger.getLogger(supp.class.getName()).log(Level.SEVERE, null, ex);
        }       
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
