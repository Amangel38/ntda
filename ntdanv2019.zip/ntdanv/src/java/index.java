/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import static java.lang.System.out;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author djo
 */
@WebServlet(urlPatterns = {"/index"})
public class index extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            /* TODO output your page here. You may use following sample code. */
       out.println("<div>TODO write content</div>");
       
       
       
       
       
  out.println(" <form name=form1 methode=GET  action='http://localhost:8080/ntdanv/jndex1'>"); // get envoie des elts du formulairesout.println("<fieldset>");
out.println(" <label>  Expediteur : </label> ");
 out.println("<input id=recherche name=recherche type=text value ='' placeholder=recherchez par votre l adrese de son expediteur>");
      out.println("<input class='f' type='submit' value='Envoyer' >");
 out.println("<br>");
  out.println("</form>");
                
       
       
       
       
       
        
        out.println("  <form name='form1' methode='GET' action='http://localhost:8080/ntdanv/add'>  ");   //envoyer le formulaire a tbl.jsp
 	out.println("<fieldset>");
 	 out.println(" <label>  Expediteur : </label> ");
 	out.println("<input id='f1' name='f1' type='text' placeholder='De' >");
 	out.println("</br>");

 	out.println("<label>  Destinataire : </label> ");
 	out.println("<input id='f2' name='f2' type='text' placeholder='a' >");
 	out.println("</br>");

 	out.println("<label>  Objet : </label>");
 	out.println("<input id='f3' name='f3' type='text' placeholder='objet' >");
 	out.println("</br>");
 	out.println("</br>");


 	out.println("<label>  Sujet : </label>");
 	out.println("</br>");
 	out.println("</br>");
 	out.println("<textarea rows='20' cols='100' name='f4' type='text' placeholder='Ecrivez votre message'></textarea>");
 	out.println("<input class='f' type='submit' value='Envoyer' >");

  out.println(" </form>");
  ResultSet rs = null ;
            try {
                Class.forName("com.mysql.jdbc.Driver");
           
      
Connection cn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ntda","root","");

//////afichage liste emails 

String liste_emails = " select * from `NTDA`.`email`  ";

Statement st = cn.createStatement();
 rs = st.executeQuery(liste_emails);  // execute men la base de donnéé

 } catch (ClassNotFoundException ex) {
                Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
            } catch (SQLException ex) {
                Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
            }
  
  
      out.println("<h1>recherche</h1>");



 out.println("expediteur      destinataire        objet         sujet   </br> ");
   
while (rs.next()){ 


        out.println(rs.getString("expediteur")+"   "+rs.getString("destinataire")+"   "+rs.getString("objet")+"  "+rs.getString("sujet")
                +"      <a href='http://localhost:8080/ntdanv/supp?email="+rs.getString("id_email")+"' >  Supprimer  </a>      </br> "); 
                            

     

  
   }



  
  
        } catch (SQLException ex) {
            Logger.getLogger(index.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
